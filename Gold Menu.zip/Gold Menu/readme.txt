Gold Menu - Macro Management System
====================================

LICENSE AGREEMENT
-----------------
By using Gold Menu, you agree to the following terms:

1. This software is provided "as is" without warranty of any kind.
2. You must have a valid subscription to use Gold Menu.
3. Redistribution of this software is strictly prohibited.
4. Modifications or reverse engineering of the software is not allowed.
5. The developer is not liable for any damages resulting from the use of this software.

For full terms of service, visit: https://raphaelcsc911.github.io/terms.html
For privacy policy, visit: https://raphaelcsc911.github.io/privacy.html

SYSTEM REQUIREMENTS
-------------------
- Windows 10 or later
- Internet connection for activation and updates
- AutoHotkey (will be installed automatically if missing)

INSTALLATION
------------
1. Run GoldMenu.exe to start the application
2. If you encounter AutoHotkey-related errors:
   - Dowload Both V1 And V2

ACTIVATION PROCESS
------------------
1. Join our Discord: https://discord.gg/Gm3UV26FjJ
2. Obtain a subscriber role
3. Generate your activation key in the #subscriber-key channel
4. Enter your key when prompted in Gold Menu

SUPPORT
-------
For technical assistance:
- Discord: https://discord.gg/Gm3UV26FjJ
- Check the #tickets for common solutions

VERSION INFORMATION
-------------------
Version: 1.1
Release Date: August 2024

© 2024 Raphaelcsc911. All rights reserved.